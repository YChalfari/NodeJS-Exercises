export const add = (a, b) => a + b;
export const printName = (name) => {
  return `my name is ${name}`;
};
